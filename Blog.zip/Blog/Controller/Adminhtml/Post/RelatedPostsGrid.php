<?php
/**
 * Copyright © 2015 Ihor Vansach (ihor@Fudugo.com). All rights reserved.
 * See LICENSE.txt for license details (http://opensource.org/licenses/osl-3.0.php).
 *
 * Glory to Ukraine! Glory to the heroes!
 */

namespace Fudugo\Blog\Controller\Adminhtml\Post;

/**
 * Blog post related posts grid controller
 */
class RelatedPostsGrid extends RelatedPosts
{

}
